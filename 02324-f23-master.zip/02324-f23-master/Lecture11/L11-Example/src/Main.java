import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

public class Main {


    private static void example1() {
        AsyncExample a = new AsyncExample();
        System.out.println("Main thread running... thread id: " + Thread.currentThread().getId());

        CompletableFuture.supplyAsync(()->a.method1()).thenAccept((s)->a.method2(s));

        System.out.println("Main thread finished");

    }

    private static void example2() {
        AsyncExample a = new AsyncExample();
        System.out.println("Main thread running... thread id: " + Thread.currentThread().getId());

        CompletableFuture.supplyAsync(()->a.method1()).thenApply((s)->a.method3(s)).thenAccept((s)->a.method2(s));

        System.out.println("Main thread finished");
    }


    private static void example3() {
        try {
            AsyncExample a = new AsyncExample();
            System.out.println("Main thread running... thread id: " + Thread.currentThread().getId());

            // CompletableFuture<String> finalResult = CompletableFuture.supplyAsync(a::method1).thenCompose(a::method4);
            CompletableFuture<String> finalResult = CompletableFuture.supplyAsync(() -> a.method1()).thenCompose((s)->a.method4(s));
            System.out.println(finalResult.get());

            System.out.println("Main thread finished");
        } catch (InterruptedException | ExecutionException e) {
            System.out.println("Exception!");
        }
    }

    private static void example4() {
        try {
            AsyncExample a = new AsyncExample();
            System.out.println("Main thread running... thread id: " + Thread.currentThread().getId());

            CompletableFuture<String> finalResult = CompletableFuture.supplyAsync(()->a.method1()).thenComposeAsync((s)->a.method4(s));
            System.out.println(finalResult.get());

            System.out.println("Main thread finished");
        } catch (InterruptedException | ExecutionException e) {
            System.out.println("Exception!");
        }
    }

    private static void exampleException() {
        AsyncExample a = new AsyncExample();
        CompletableFuture<String> f = a.methodException();

        f.thenAcceptAsync(s -> {
                    System.out.println("Result: " + s);
                })
         .exceptionally(e -> {
                    System.err.println("Error! " + e.getMessage());
                    return null;
                });
    }

    public static void main(String[] args) {
        //example1();
        // example2();
        example3();
        //  example4();
    }
}
