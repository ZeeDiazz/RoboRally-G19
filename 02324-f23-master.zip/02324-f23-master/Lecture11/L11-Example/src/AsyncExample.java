import java.util.Arrays;
import java.util.concurrent.CompletableFuture;

public class AsyncExample {
    // no argument, returns a value
    public String method1() {
        System.out.println("Running method1... thread id: " + Thread.currentThread().getId());
        String returnValue = "Hello from method1!";
        System.out.println("Return value: " + returnValue);
        return returnValue;
    }
    // has argument, no return value
    public void method2(String arg) {
        System.out.println("Running method2... thread id: " + Thread.currentThread().getId());
        System.out.println("Incoming argument: " + arg);
    }

    // has argument, returns a value
    public String method3(String arg) {
        System.out.println("Running method3... thread id: " + Thread.currentThread().getId());
        System.out.println("Incoming argument: " + arg);
        String returnValue = "Hello from method3!";
        System.out.println("Return value: " + returnValue);
        return returnValue;
    }

    // returns CompletableFuture
    public CompletableFuture<String> method4(String arg) {
        return CompletableFuture.supplyAsync(()->{
            System.out.println("Running method4... thread id: " + Thread.currentThread().getId());
            return arg + "  - Well, hello to you too!";
        });
    }

    // returns CompletableFuture which throws an exception
    public CompletableFuture<String> methodException() {
        return CompletableFuture.supplyAsync(() -> {
            try {
                int i = 1 / 0;  //  Do not try it at home :)))
            } catch (Exception e) {
                throw new RuntimeException("Division by zero!!!", e);
            }
            return "Hello World!";
        });
    }

}
