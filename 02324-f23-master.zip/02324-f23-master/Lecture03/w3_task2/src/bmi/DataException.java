package bmi;

public class DataException extends Exception {
    private static final long serialVersionUID = 3184201770220225838L;

    public DataException() {
        super();
    }
}
