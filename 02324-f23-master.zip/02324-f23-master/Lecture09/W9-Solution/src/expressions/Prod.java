package expressions;

public class Prod extends BinaryExp {
    public Prod(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public int eval() {
        return left.eval() * right.eval();
    }
}
