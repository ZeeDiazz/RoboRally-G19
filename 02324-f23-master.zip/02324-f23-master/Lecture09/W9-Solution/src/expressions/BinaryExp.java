package expressions;

public abstract class BinaryExp extends Expression {
    protected Expression left;
    protected Expression right;

    public BinaryExp(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
}
