package expressions;

public class Main {

    static Expression constF(int i) {
        return new Const(i);
    }

    static Expression sumF(Expression l, Expression r) {
        return new Sum(l, r);
    }

    static Expression prodF(Expression l, Expression r) {
        return new Prod(l, r);
    }

    public static void main(String[] args) {
        Expression myExp = sumF(constF(3), prodF(constF(4), sumF(constF(5), constF(6))));
        System.out.println("Value of 3+4*(5+6)is: " + myExp.eval());
    }
}
