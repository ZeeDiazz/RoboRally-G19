package expressions;

public class Const extends Expression {
    private int value;

    public Const(int value) {
        this.value = value;
    }

    @Override
    public int eval() {
        return value;
    }
}
