package expressions;

public class Sum extends BinaryExp {
    public Sum(Expression left, Expression right) {
        super(left, right);
    }

    @Override
    public int eval() {
        return left.eval() + right.eval();
    }
}
