package fibonacci;

import expressions.Const;
import expressions.Expression;
import expressions.Sum;

public class Main {

    static public int fibonacci(int n)  {
        if (n < 0) return -1; // not valid input
        if (n < 2) return n;
        return fibonacci(n - 1) + fibonacci(n - 2);
    }

    public static void main(String[] args) {
        int r = fibonacci(10);
        System.out.println("Fubonacci sequence for 10 is:" + r );
    }

}
