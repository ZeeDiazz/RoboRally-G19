package students;
import com.google.gson.Gson;

public class Main {
    public static void main(String args[]) {

        Student student = new Student();
        student.setAge(20);
        student.setName("Valdemar");

        Gson gson = new Gson();
        String jsonString = gson.toJson(student);
        System.out.println(jsonString);

        Student student1 = gson.fromJson(jsonString, Student.class);
        System.out.println(student1);
    }
}
