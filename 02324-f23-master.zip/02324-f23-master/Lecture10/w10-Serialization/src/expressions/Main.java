package expressions;

import adapter.Adapter;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.reflect.Type;

public class Main {

    static Expression constF(int i) {
        return new Const(i);
    }

    static Expression sumF(Expression l, Expression r) {
        return new Sum(l, r);
    }

    static Expression prodF(Expression l, Expression r) {
        return new Prod(l, r);
    }

    public static void main(String[] args) {
        exprToFile();
        exprFromFile();
    }

    public static void exprToFile() {
        String filePath = "expr.json";
        Expression myExp = sumF(constF(3), prodF(constF(4), sumF(constF(5), constF(6))));
        Expression myExp2 = prodF(sumF(constF(4), sumF(constF(5), constF(6))), constF(7));
        Expression[] arr = {myExp, myExp2};

        System.out.println("Value 0  of 3+4*(5+6)is: " + myExp.eval());
        System.out.println("Value 1 of (4+(5+6))*7 is: " + myExp2.eval());
        FileWriter fileWriter = null;
        try {
            fileWriter = new FileWriter(filePath);
            Adapter<Expression> ada = new Adapter<Expression>();
            GsonBuilder gb = new GsonBuilder();
            gb.registerTypeAdapter(Expression.class, ada);
            gb.setPrettyPrinting();
            Gson gson = gb.create();
            gson.toJson(arr, Expression[].class, fileWriter);
            fileWriter.close();

        } catch (IOException e) {
            e.printStackTrace();
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (IOException e2) {
                }
            }
        }

    }

    public static void exprFromFile() {
    //  implement this method
    }

}
