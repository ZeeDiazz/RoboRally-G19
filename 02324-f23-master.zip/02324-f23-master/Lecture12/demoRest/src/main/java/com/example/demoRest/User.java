package com.example.demoRest;

public class User {
}
