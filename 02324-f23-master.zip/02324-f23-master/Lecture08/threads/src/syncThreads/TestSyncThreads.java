package syncThreads;

public class TestSyncThreads {

    private static SyncAccount account;

    public static void main(String[] args) {
        account = new SyncAccount();

        IncrementSyncAccountThread incrementAccount1 = new IncrementSyncAccountThread(account, 1);
        IncrementSyncAccountThread incrementAccount2 = new IncrementSyncAccountThread(account, 2);

        incrementAccount1.start();
        incrementAccount2.start();

        try {
            incrementAccount1.join();
            incrementAccount2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Account balance: " + account.getBalance());
    }
}
