package syncThreads;

public class SyncAccount {

   private int balance = 0;

    public synchronized int getBalance() {
        return balance;
    }

    public synchronized void add(int amount) {
        int current = balance;
        try {
            Thread.sleep(1);
        }
        catch (InterruptedException e) {
            // ignore
        }
        finally {
            balance = current + amount;
        }

    }
}
