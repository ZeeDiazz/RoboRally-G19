package threads;

public class TestThreads {

   private static Account account;

    public static void main(String[] args) {
        account = new Account();

        IncrementAccountThread incrementAccount1 = new IncrementAccountThread(account, 1);
        IncrementAccountThread incrementAccount2 = new IncrementAccountThread(account, 2);

        incrementAccount1.start();
        incrementAccount2.start();

        try {
            incrementAccount1.join();
            incrementAccount2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Account balance: " + account.getBalance());
    }
}
