package threads;

public class Account {

    private final int DELAY = (int) (1000 * Math.random());

    private int balance = 0;

    public  int getBalance() {
        return balance;
    }

    public  void add(int amount) {
        int current = balance;

        for (int i = 0; i < DELAY; i++) {
        }
        /* A for loop is not a good way to wait for something
           (this is called "busy waiting", because it wastes
           processor time and energy). The same effect can
           be achieved in a more efficient way by putting the
           current thread to sleep. */

        balance = current + amount;
    }
}
