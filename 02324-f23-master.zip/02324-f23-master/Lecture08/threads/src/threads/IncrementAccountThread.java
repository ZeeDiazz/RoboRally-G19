package threads;

public class IncrementAccountThread extends Thread {

    private static final int ITERATIONS = 1000;
    private Account account;
    private int threadNumber;

    // constructor – call it in this exercise by giving the same account object
   public IncrementAccountThread(Account account, int threadNumber) {
        this.account = account;
        this.threadNumber = threadNumber;
    }

    void makeIncrements() { // called when a thread starts
        System.out.println("Thread " + threadNumber + " started!");
        for (int i = 0; i < ITERATIONS; i++) {
            account.add(1);
        }
        System.out.println("Thread " + threadNumber + ": " + account.getBalance());
        System.out.println("Thread " + threadNumber + " finished!");
    }

    @Override
    public void run() {
        makeIncrements();
    }
}
